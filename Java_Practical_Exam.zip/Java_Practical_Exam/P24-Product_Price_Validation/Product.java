public class Product {
    private int id;
    private String name;
    private double price;

    public void setId(int id) { this.id = id; }
    public int getId() { return id; }

    public void setName(String name) { this.name = name; }
    public String getName() { return name; }

    public void setPrice(double price) {
        if (price >= 0) {
            this.price = price;
        } else {
            System.out.println("Error: Price cannot be negative!");
        }
    }
    public double getPrice() { return price; }

    public static void main(String[] args) {
        Product p = new Product();
        p.setId(101);
        p.setName("Laptop");
        
        System.out.println("Trying to set negative price:");
        p.setPrice(-500);
        
        System.out.println("Setting valid price:");
        p.setPrice(45000);
        
        System.out.println("Product: " + p.getName() + " costs " + p.getPrice());
    }
}
