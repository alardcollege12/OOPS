public class Time {
    int hours;
    int minutes;
    int seconds;

    Time(int h, int m, int s) {
        hours = h;
        minutes = m;
        seconds = s;
    }

    void addTime(Time t1, Time t2) {
        this.seconds = t1.seconds + t2.seconds;
        this.minutes = t1.minutes + t2.minutes + (this.seconds / 60);
        this.seconds = this.seconds % 60;
        this.hours = t1.hours + t2.hours + (this.minutes / 60);
        this.minutes = this.minutes % 60;
    }

    void display() {
        System.out.println(hours + " hr : " + minutes + " min : " + seconds + " sec");
    }

    public static void main(String[] args) {
        Time t1 = new Time(2, 45, 50);
        Time t2 = new Time(1, 20, 30);
        Time result = new Time(0, 0, 0);

        result.addTime(t1, t2);
        
        System.out.print("Total Time: ");
        result.display();
    }
}
