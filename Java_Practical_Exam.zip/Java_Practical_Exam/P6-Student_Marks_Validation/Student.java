public class Student {
    private double marks;

    public void setMarks(double m) {
        if (m < 0 || m > 100) {
            System.out.println("Invalid marks!");
        } else {
            marks = m;
            System.out.println("Marks updated successfully.");
        }
    }

    public double getMarks() {
        return marks;
    }

    public static void main(String[] args) {
        Student s = new Student();
        
        System.out.println("Trying to set marks to 105:");
        s.setMarks(105);
        
        System.out.println("Trying to set marks to 85:");
        s.setMarks(85);
        
        System.out.println("Current Marks: " + s.getMarks());
    }
}
