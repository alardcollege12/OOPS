public class Rectangle {
    double length;
    double breadth;

    Rectangle(double l, double b) {
        length = l;
        breadth = b;
    }

    void calculateArea() {
        System.out.println("Area: " + (length * breadth));
    }

    void calculatePerimeter() {
        System.out.println("Perimeter: " + (2 * (length + breadth)));
    }

    public static void main(String[] args) {
        Rectangle r = new Rectangle(5.5, 4.0);
        r.calculateArea();
        r.calculatePerimeter();
    }
}
