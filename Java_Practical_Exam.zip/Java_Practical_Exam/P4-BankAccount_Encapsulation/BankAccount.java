public class BankAccount {
    private int accountNumber;
    private double balance;

    public void setAccountNumber(int accNo) {
        accountNumber = accNo;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setBalance(double amt) {
        if (amt >= 0) {
            balance = amt;
        }
    }

    public double getBalance() {
        return balance;
    }

    public static void main(String[] args) {
        BankAccount acc = new BankAccount();
        acc.setAccountNumber(5544);
        acc.setBalance(15000);

        System.out.println("Account No: " + acc.getAccountNumber());
        System.out.println("Balance: " + acc.getBalance());
    }
}
