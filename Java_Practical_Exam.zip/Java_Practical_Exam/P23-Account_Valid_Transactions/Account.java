public class Account {
    private double balance = 0;

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount);
        } else {
            System.out.println("Invalid deposit amount");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawn: " + amount);
        } else {
            System.out.println("Invalid amount or insufficient balance");
        }
    }

    public void display() {
        System.out.println("Current Balance: " + balance);
    }

    public static void main(String[] args) {
        Account acc = new Account();
        acc.deposit(5000);
        acc.withdraw(2000);
        acc.withdraw(6000); 
        acc.display();
    }
}
