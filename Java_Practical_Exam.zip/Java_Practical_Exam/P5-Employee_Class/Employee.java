public class Employee {
    private int id;
    private String name;
    private double salary;

    public void setId(int empId) {
        id = empId;
    }

    public int getId() {
        return id;
    }

    public void setName(String empName) {
        name = empName;
    }

    public String getName() {
        return name;
    }

    public void setSalary(double empSalary) {
        salary = empSalary;
    }

    public double getSalary() {
        return salary;
    }

    public static void main(String[] args) {
        Employee emp = new Employee();
        emp.setId(101);
        emp.setName("Ramesh");
        emp.setSalary(25000);

        System.out.println("ID: " + emp.getId());
        System.out.println("Name: " + emp.getName());
        System.out.println("Salary: " + emp.getSalary());
    }
}
