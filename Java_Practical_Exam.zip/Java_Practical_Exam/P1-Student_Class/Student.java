public class Student {
    String name;
    int rollNo;
    double marks;

    public static void main(String[] args) {
        Student s1 = new Student();
        s1.name = "Amit";
        s1.rollNo = 1;
        s1.marks = 88.5;

        System.out.println("Student Name: " + s1.name);
        System.out.println("Roll Number: " + s1.rollNo);
        System.out.println("Marks: " + s1.marks);
    }
}
