public class Student {
    void setMarks(int marks) throws Exception {
        if (marks < 0 || marks > 100) {
            throw new Exception("Invalid Marks Entered");
        } else {
            System.out.println("Marks successfully set to: " + marks);
        }
    }

    public static void main(String[] args) {
        Student s = new Student();
        
        try {
            s.setMarks(120);
        } catch (Exception e) {
            System.out.println("Error caught: " + e.getMessage());
        }
    }
}
