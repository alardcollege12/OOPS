public class BankAccount {
    int accountNumber;
    double balance;

    BankAccount(int accNo, double initialBalance) {
        accountNumber = accNo;
        balance = initialBalance;
    }

    void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited: " + amount);
    }

    void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawn: " + amount);
        } else {
            System.out.println("Not enough balance");
        }
    }

    public static void main(String[] args) {
        BankAccount acc = new BankAccount(1001, 5000);
        System.out.println("Initial Balance: " + acc.balance);
        acc.deposit(2000);
        System.out.println("Balance after deposit: " + acc.balance);
        acc.withdraw(1000);
        System.out.println("Balance after withdrawal: " + acc.balance);
        acc.withdraw(10000);
    }
}
